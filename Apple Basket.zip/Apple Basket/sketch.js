//Fruit array
let fruitsArray = [];

//Basket movement
let basketX = 250;
let basketY = 445;

//Score
let score = 0;

//Images
let apple, basket;

function preload() 
{
    apple = loadImage("https://cdn.glitch.global/6187078a-aa0e-443c-8b01-2be40d57497c/apple.png?v=1689992073083");
    basket = loadImage("https://cdn.glitch.global/6187078a-aa0e-443c-8b01-2be40d57497c/basket.png?v=1689992056037");
    nature = loadImage("https://cdn.glitch.global/6187078a-aa0e-443c-8b01-2be40d57497c/tree.jpg?v=1689993032679")
}

function setup() 
{
    createCanvas(700, 500);
    background(0);
    imageMode(CENTER);
    frameRate(60);
    noStroke();
    setInterval(dropFruit, 800); //adds a interval between each apple drop
}

function draw() 
{
    background(0);

    //Score counter
    fill(255);
    textSize(30);
    text("Score: " + score, 500, 40);
  
    // Nature Background
    image(nature, 250,250,500,500)
    //Basket generatipn
    fill(255, 255, 0);
    image(basket, basketX, basketY, 75, 75);
    
    //Basket controls
    if (keyIsDown(LEFT_ARROW))
    {
       basketX -= 3;
    }
    if (keyIsDown(RIGHT_ARROW)) 
    {
       basketX += 3;
    }
  
    //Generating fruits
    for (let i = 0; i < fruitsArray.length; i++) 
    {
        fill(255, 0, 0);
        image(apple, fruitsArray[i].xPos, fruitsArray[i].yPos, 50, 50); 
        fruitsArray[i].yPos += fruitsArray[i].speedValue;
        if (fruitsArray[i].yPos + 50 >= basketY && fruitsArray[i].yPos <= basketY + 50 && fruitsArray[i].xPos + 50 >= basketX && fruitsArray[i].xPos <= basketX + 50) 
        {
            fruitsArray.splice(i, 1); //Discarding fruits
            score += 1;
        } 
        else if (fruitsArray[i].yPos > height) 
        {
            fruitsArray.splice(i, 1);
            if (score > 0)
            {
                score -= 1;
            }
          if (score == 0) {
            score ++
            score *= -1
          }
        }
    }

    //Ends game when objective is reached
    if (score == 30)
    {
        noLoop();
        background(0);
        textSize(75);
        fill(0,255,0);
        text("YOU WIN!", 75, 270);
    }
    if (score < 0) {
      noLoop();
      background(0);
      textSize(75);
      fill(255,0,0);
      text("YOU LOSE", 75, 270);
    }
}

function dropFruit() 
{
    let temp = new Fruit(random(25, 475), -50, 4 + score / 5);
    fruitsArray.push(temp);
}

//Fruit constructor
class Fruit
{
    constructor(x, y, speed) 
    { 
        this.xPos = x;
        this.yPos = y;
        this.speedValue = speed;
    }
} 